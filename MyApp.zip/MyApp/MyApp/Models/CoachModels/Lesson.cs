﻿namespace coach.Models
{
    public enum PackageLevel
    {
        Basic,      // Cơ bản
        Standard,   // Trung bình
        Premium     // VIP
    }
    public class Lesson
    {
        public string Id { get; set; }

        public required string CourseName { get; set; }  
        public int NumberOfSessions { get; set; }
        public string CoachProfileId { get; set; }

        public required CoachProfile CoachProfile { get; set; }
        public PackageLevel PackageLevel { get; set; }  // Gói học

        public decimal Price { get; set; }              // Giá tiền
    }
}
