﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyApp.Migrations
{
    /// <inheritdoc />
    public partial class FixCoachProfileIdType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Lessons_CoachProfiles_CoachProfileId1",
                table: "Lessons");

            migrationBuilder.DropIndex(
                name: "IX_Lessons_CoachProfileId1",
                table: "Lessons");

            migrationBuilder.DropColumn(
                name: "CoachProfileId1",
                table: "Lessons");

            migrationBuilder.AlterColumn<string>(
                name: "CoachProfileId",
                table: "Lessons",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Lessons_CoachProfileId",
                table: "Lessons",
                column: "CoachProfileId");

            migrationBuilder.AddForeignKey(
                name: "FK_Lessons_CoachProfiles_CoachProfileId",
                table: "Lessons",
                column: "CoachProfileId",
                principalTable: "CoachProfiles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Lessons_CoachProfiles_CoachProfileId",
                table: "Lessons");

            migrationBuilder.DropIndex(
                name: "IX_Lessons_CoachProfileId",
                table: "Lessons");

            migrationBuilder.AlterColumn<int>(
                name: "CoachProfileId",
                table: "Lessons",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "CoachProfileId1",
                table: "Lessons",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Lessons_CoachProfileId1",
                table: "Lessons",
                column: "CoachProfileId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Lessons_CoachProfiles_CoachProfileId1",
                table: "Lessons",
                column: "CoachProfileId1",
                principalTable: "CoachProfiles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
