﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyApp.Migrations
{
    /// <inheritdoc />
    public partial class AlterTeachingMaterial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TeachingMaterials_CoachProfiles_CoachProfileId1",
                table: "TeachingMaterials");

            migrationBuilder.DropIndex(
                name: "IX_TeachingMaterials_CoachProfileId1",
                table: "TeachingMaterials");

            migrationBuilder.DropColumn(
                name: "CoachProfileId1",
                table: "TeachingMaterials");

            migrationBuilder.AlterColumn<string>(
                name: "CoachProfileId",
                table: "TeachingMaterials",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateTable(
                name: "Materials",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FileName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Path = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UploadedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TeachingMaterialId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Materials", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Materials_TeachingMaterials_TeachingMaterialId",
                        column: x => x.TeachingMaterialId,
                        principalTable: "TeachingMaterials",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_TeachingMaterials_CoachProfileId",
                table: "TeachingMaterials",
                column: "CoachProfileId");

            migrationBuilder.CreateIndex(
                name: "IX_Materials_TeachingMaterialId",
                table: "Materials",
                column: "TeachingMaterialId");

            migrationBuilder.AddForeignKey(
                name: "FK_TeachingMaterials_CoachProfiles_CoachProfileId",
                table: "TeachingMaterials",
                column: "CoachProfileId",
                principalTable: "CoachProfiles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TeachingMaterials_CoachProfiles_CoachProfileId",
                table: "TeachingMaterials");

            migrationBuilder.DropTable(
                name: "Materials");

            migrationBuilder.DropIndex(
                name: "IX_TeachingMaterials_CoachProfileId",
                table: "TeachingMaterials");

            migrationBuilder.AlterColumn<int>(
                name: "CoachProfileId",
                table: "TeachingMaterials",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "CoachProfileId1",
                table: "TeachingMaterials",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_TeachingMaterials_CoachProfileId1",
                table: "TeachingMaterials",
                column: "CoachProfileId1");

            migrationBuilder.AddForeignKey(
                name: "FK_TeachingMaterials_CoachProfiles_CoachProfileId1",
                table: "TeachingMaterials",
                column: "CoachProfileId1",
                principalTable: "CoachProfiles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
